#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np   
import pandas as pd    
import seaborn as sns
from sklearn import metrics
import matplotlib.pyplot as plt


# ### Data Extraction

# In[2]:


df=pd.read_csv("CC GENERAL.csv")


# In[3]:


df.head()


# ### EDA

# In[4]:


df.info()


# In[5]:


print("Number of rows: ",df.shape[0], "\n""Number of columns: ",df.shape[1])


# In[6]:


df.describe().T


# In[7]:


def metrics_val(col):
    Q1 = df[col].quantile(0.25)
    Q2 = df[col].quantile(0.50)
    Q3 = df[col].quantile(0.75)
    print("Below are the metrics for ",col,":")
    print("Minimum value : ",df[col].min())
    print("Maximum value : ",df[col].max())
    print("First Quartile - ", Q1, "Median - ", Q2, "Third Quartile - ", Q3)
    IQR = Q3-Q1
    print("Inter-quatile Region - ",IQR, "\n\n")

for col in df.columns:
    if(col != 'CUST_ID'):
        metrics_val(col)


# In[8]:


duplicates = df.duplicated()
print('Number of duplicate rows = %d' % (duplicates.sum()))


# ### Imputation of missing values

# In[9]:


(df=='?').sum()


# In[10]:


df.isnull().sum()


# In[11]:


num = ['CREDIT_LIMIT','MINIMUM_PAYMENTS']
plt.figure(figsize=(15,10))
df[num].boxplot(vert=0)
plt.title('With Outliers',fontsize=16)
plt.show()


# Both the variables have possible outliers and hence median would be used for imputaiton

# In[12]:


df['MINIMUM_PAYMENTS'] = df['MINIMUM_PAYMENTS'].fillna(df['MINIMUM_PAYMENTS'].median())
df['CREDIT_LIMIT'] = df['CREDIT_LIMIT'].fillna(df['CREDIT_LIMIT'].median())
df.isnull().sum()


# #### Dropping CUST_ID column
# 
# CUST_ID is an object data type column and it is unique value, there is no need of it in clustering, so we will drop it.

# In[13]:


df = df.drop('CUST_ID',axis = 1)
df.head()


# In[14]:


cols = df.columns


# ### Data Visualization

# #### Univariate Analysis

# In[15]:


fig, axes = plt.subplots(nrows=3,ncols=2)
fig.set_size_inches(18,15)

a = sns.histplot(x=df[cols[0]] , ax=axes[0][0])
a.set_title(cols[0],fontsize=10)

a = sns.histplot(x=df[cols[1]] , ax=axes[0][1])
a.set_title(cols[1],fontsize=10)

a = sns.histplot(x=df[cols[2]] , ax=axes[1][0])
a.set_title(cols[2],fontsize=10)

a = sns.histplot(x=df[cols[3]] , ax=axes[1][1])
a.set_title(cols[3],fontsize=10)

a = sns.histplot(x=df[cols[4]] , ax=axes[2][0])
a.set_title(cols[4],fontsize=10)

a = sns.histplot(x=df[cols[5]] , ax=axes[2][1])
a.set_title(cols[5],fontsize=10)

plt.show()


# In[16]:


fig, axes = plt.subplots(nrows=3,ncols=2)
fig.set_size_inches(18,15)

a = sns.histplot(x=df[cols[6]] , ax=axes[0][0])
a.set_title(cols[6],fontsize=10)

a = sns.histplot(x=df[cols[7]] , ax=axes[0][1])
a.set_title(cols[7],fontsize=10)

a = sns.histplot(x=df[cols[8]] , ax=axes[1][0])
a.set_title(cols[8],fontsize=10)

a = sns.histplot(x=df[cols[9]] , ax=axes[1][1])
a.set_title(cols[9],fontsize=10)

a = sns.histplot(x=df[cols[10]] , ax=axes[2][0])
a.set_title(cols[10],fontsize=10)

a = sns.histplot(x=df[cols[11]] , ax=axes[2][1])
a.set_title(cols[11],fontsize=10)

plt.show()


# In[17]:


fig, axes = plt.subplots(nrows=3,ncols=2)
fig.set_size_inches(18,15)

a = sns.histplot(x=df[cols[12]] , ax=axes[0][0])
a.set_title(cols[12],fontsize=10)

a = sns.histplot(x=df[cols[13]] , ax=axes[0][1])
a.set_title(cols[13],fontsize=10)

a = sns.histplot(x=df[cols[14]] , ax=axes[1][0])
a.set_title(cols[14],fontsize=10)

a = sns.histplot(x=df[cols[15]] , ax=axes[1][1])
a.set_title(cols[15],fontsize=10)

a = sns.histplot(x=df[cols[16]] , ax=axes[2][0])
a.set_title(cols[16],fontsize=10)

plt.show()


# Insights from Histogram:
# - Tenure of credit card service is mostly 12 months for the customers
# - Account balance amount is maintained as zero by most of the customers while the account balance update frequency is higher for most of the users.
# - We have almost equal amount of customers who purchase more frequently and who purchase more rarely using the credit card.
# - Most of the customers doesn't prefer to make purchases in one-go.
# - Frequency of purchases through installments and advance payments are very less among most of the users.
# - Credit limit for most of the customers falls within the range of 1000 to 3000
# - Payments done by the customers is predominantly in the range of 500 to 2000

# #### Bivariate Analysis

# In[18]:


plt.subplots(figsize = (20,12))
sns.heatmap(df.corr(),annot=True,cmap='Blues')
plt.show()


# - We can notice that there is higher correlation between purchases and oneoff_purchases. 
# - Second highly correlated features are purchase_installment_frequency and purchase frequency. 
# - Also we can see more correlation between cash_advance_frequency and cash_advance_trx

# #### Multivariate Analysis

# In[19]:


linear_plot = sns.lmplot(data=df, x = 'ONEOFF_PURCHASES', y = 'PURCHASES', hue = 'TENURE', palette="Set2", height=8)
linear_plot.set(xlabel='ONEOFF PURCHASES', ylabel='PURCHASES')
linear_plot.set(title='Linear Regression between Purchases and Maximum amount of purchase ')
plt.show()


# From the above graph, we can see that customers who made more purchases in one go usually have higher overall purchase amounts as well.

# In[20]:


plt.subplots(figsize = (20,12))
scat_plot = sns.scatterplot(data=df, x= 'CREDIT_LIMIT', y = 'BALANCE', hue = 'TENURE',palette = 'Set2',legend = 'full')
scat_plot.set(xlabel='Credit limit', ylabel='Balance')
scat_plot.set(title='Scatter plot between Credit limit and Balance with Tenure')
plt.show()


# From the above plot we can notice that as balance increases credit limit also increases and customers prefer tenure of 12 months mostly.

# In[21]:


plt.subplots(figsize = (20,12))
scat_plot = sns.scatterplot(data=df, x = 'CREDIT_LIMIT', y = 'INSTALLMENTS_PURCHASES', hue = 'TENURE')
scat_plot.set(xlabel='Credit limit', ylabel='Installment Purchase')
scat_plot.set(title='Scatter plot between Credit limit and Installment Purchase with Tenure')
plt.show()


# There is no relation between credit limit and installment purchase irrespective of the tenure

# ### Outlier Treatment

# In[22]:


plt.figure(figsize = (15,25))
for i in range(len(cols)):
    plt.subplot(6, 3, i+1)
    sns.boxplot(y = df[cols[i]], data = df)
    plt.title('Boxplot of {}'.format(cols[i]))
    plt.tight_layout()
plt.title('With Outliers')
plt.show()


# In[23]:


# Using flooring and capping method to treat outliers below 15 percent and above 85 percent, as we dont have to loose possible real data
def treat_outlier(col):
    sorted(col)
    Q1,Q3=np.percentile(col,[15,85])
    IQR=Q3-Q1
    lower_range=Q1-(1.5*IQR)
    upper_range=Q3+(1.5*IQR)
    return lower_range, upper_range


# In[24]:


for feature in df.columns: 
    lr,ur=treat_outlier(df[feature])
    df[feature]=np.where(df[feature]>ur,ur,df[feature])
    df[feature]=np.where(df[feature]<lr,lr,df[feature])


# In[25]:


print('After Outliers Treatment')
plt.figure(figsize = (15,25))
for i in range(len(cols)):    
    plt.subplot(6, 3, i+1)
    sns.boxplot(y = df[cols[i]], data = df)
    plt.title('Boxplot of {}'.format(cols[i]))
    plt.tight_layout()
plt.show()


# ### Data Scaling

# In[26]:


from sklearn.preprocessing import StandardScaler
scale = StandardScaler()
df_scaled = pd.DataFrame(scale.fit_transform(df),columns=df.columns)
df_scaled.head()


# ### Clustering

# #### KMeans Model

# In[27]:


# Forming clusters with K = 1 to 11 and comparing the WSS
from sklearn.cluster import KMeans
wss =[] 
for i in range(1,11):
    KM = KMeans(n_clusters=i,random_state=1)
    KM.fit(df_scaled)
    wss.append(KM.inertia_)
wss


# In[29]:


l=[1,2,3,4,5,6,7,8,9,10]
sns.pointplot(x=l,y=wss)
plt.show()


# In[30]:


# Calculating silhouette_score
from sklearn.metrics import silhouette_samples, silhouette_score
for i in range(2,11):
    k_means = KMeans(n_clusters = i,random_state=1)
    k_means.fit(df_scaled)
    labels = k_means.labels_
    print("Silhouette score for {} clusters using KMeans: {}".format(i,silhouette_score(df_scaled,labels)))


# The highest value is 0.277 with clusters = 2  
# 
# Silhouette score for 2 clusters using KMeans is higher than other number of clusters.

# #### Agglomerative Clustering

# In[31]:


from sklearn.cluster import AgglomerativeClustering
for i in range(2,11):
    hac = AgglomerativeClustering(i)
    hac.fit(df_scaled)
    labels = hac.labels_
    print("Silhouette score for {} clusters using Agglomerative: {}".format(i,silhouette_score(df_scaled,labels)))


# The highest value is 0.179 with clusters = 2  
# 
# Silhouette score for 2 clusters using Agglomerative is higher than other number of clusters.

# #### GaussianMixture

# In[32]:


from sklearn.mixture import GaussianMixture
for i in range(2,11):
    gm = GaussianMixture(i)
    gm.fit(df_scaled)
    labels = gm.predict(df_scaled)
    print("Silhouette score for {} clusters using GaussianMixture: {}".format(i,silhouette_score(df_scaled,labels)))


# The highest value is 0.23 with clusters = 2
# 
# Silhouette score for 2 clusters using GaussianMixture is higher than other number of clusters.

# In[33]:


from sklearn.cluster import DBSCAN
for i in np.arange(1,5,0.5):
    for j in range(2,4):
        db = DBSCAN(eps = i, min_samples = j).fit(df_scaled)        
        print("Silhouette score using DBSCAN with eps = {} , min_samples = {}: {}".format(i,j,silhouette_score(df_scaled,db.labels_)))
        print("Number of classes excluding noise = {} with noise mentioned as -1 class \n\n".format(len(np.unique(db.labels_))-1))


# In[34]:


db = DBSCAN(eps = 3, min_samples = 3).fit(df_scaled)
y_means = db.fit_predict(df_scaled)
np.unique(db.labels_)


# The highest value is 0.465 with eps = 4.5 , min_samples = 2 but it has only one class excluding noise. 
# 
# Hence we are considering the value 0.298 obtained from DBSCAN with eps = 3.0 , min_samples = 3 having two classes and noise.

# The best algorithm with this data is DBSCAN that spilts the data into two clusters with silhouette_score = 0.298

# #### Appending Clusters to the original dataset

# In[35]:


df["cluster_group"] = db.labels_
df.head()


# In[36]:


df["cluster_group"].unique()


# #### Cluster Profiling

# In[37]:


clust_profile=df.groupby('cluster_group').mean()
clust_profile['freq']=df["cluster_group"].value_counts().sort_index()
clust_profile


# In[38]:


clust_profile['freq']


# We can observe that there are only 6 data in one cluster and all other data are under one cluster with some noise.

# In[39]:


k_means = KMeans(n_clusters = 2,random_state=1)
k_means.fit(df_scaled)
labels = k_means.labels_
df["kmeans_cluster_group"] = labels
df.head()


# In[41]:


clust_profile_kmeans=df.groupby('kmeans_cluster_group').mean()
clust_profile_kmeans['freq']=df["kmeans_cluster_group"].value_counts().sort_index()
clust_profile_kmeans


# In[42]:


clust_profile_kmeans['freq']


# Even if the silhouette score is lesser for kmeans. we can observe the clustering has some definite number of data in both the clusters.

# In[ ]:




